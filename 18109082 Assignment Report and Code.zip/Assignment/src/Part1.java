class ReentrantLock {
    private boolean isLocked = false;
    private Thread lockedBy = null;
    private int lockCount = 0;

    public synchronized void lock() throws InterruptedException {
        while (isLocked && lockedBy != Thread.currentThread()) {
            wait();
        }
        isLocked = true;
        lockedBy = Thread.currentThread();
        lockCount++;
    }

    public synchronized void unlock() {
        if (lockedBy == Thread.currentThread()) {
            lockCount--;
            if (lockCount == 0) {
                isLocked = false;
                lockedBy = null;
                notifyAll();
            }
        }
    }

    public synchronized boolean isLocked() {
        return isLocked;
    }

    public synchronized Thread getLockedBy() {
        return lockedBy;
    }

    public synchronized void setLocked(boolean locked) {
        this.isLocked = locked;
    }

    public synchronized void setLockedBy(Thread thread) {
        this.lockedBy = thread;
    }

    public synchronized int getLockCount() {
        return lockCount;
    }

    public synchronized void setLockCount(int count) {
        this.lockCount = count;
    }
}

class Cinema {
    private static final int NUM_THEATRES = 3;
    private static final int SEATS_PER_THEATRE = 20;
    private static final int NUM_CUSTOMERS = 100;

    private static final ReentrantLock[] theatreLocks = new ReentrantLock[NUM_THEATRES];
    private static final boolean[][] seats = new boolean[NUM_THEATRES][SEATS_PER_THEATRE];

    static {
        for (int i = 0; i < NUM_THEATRES; i++) {
            theatreLocks[i] = new ReentrantLock();
        }
    }

    private static class Customer implements Runnable {
        private int theatreId;
        private int numSeats;

        public Customer(int theatreId, int numSeats) {
            this.theatreId = theatreId;
            this.numSeats = numSeats;
        }

        private void reserveSeats() throws InterruptedException {
            acquireLock(theatreLocks[theatreId]);

            try {
                for (int i = 0; i < numSeats; i++) {
                    int seatId = -1;

                    // Find an available seat
                    for (int j = 0; j < SEATS_PER_THEATRE; j++) {
                        if (!seats[theatreId][j]) {
                            seatId = j;
                            break;
                        }
                    }

                    if (seatId == -1) {
                        System.out.println("Customer couldn't find a seat in theatre " + theatreId);
                        return;
                    }

                    seats[theatreId][seatId] = true; // Reserve the seat
                    System.out.println("Customer reserved Seat " + seatId + " in theatre " + theatreId);
                    Thread.sleep((long) (Math.random() * 500 + 500)); // Delay before confirming reservation
                }

                System.out.println("Customer successfully reserved " + numSeats + " seat(s) in theatre " + theatreId);
            } finally {
                releaseLock(theatreLocks[theatreId]);
            }
        }

        private void acquireLock(ReentrantLock lock) throws InterruptedException {
            lock.lock();
        }

        private void releaseLock(ReentrantLock lock) {
            lock.unlock();
        }

        @Override
        public void run() {
            try {
                reserveSeats();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Thread[] customers = new Thread[NUM_CUSTOMERS];

        // Create customer threads
        for (int i = 0; i < NUM_CUSTOMERS; i++) {
            int theatreId = (int) (Math.random() * NUM_THEATRES);
            int numSeats = (int) (Math.random() * 3 + 1);
            customers[i] = new Thread(new Customer(theatreId, numSeats));
        }

        // Start customer threads
        for (int i = 0; i < NUM_CUSTOMERS; i++) {
            customers[i].start();
        }

        // Wait for all customer threads to finish
        for (int i = 0; i < NUM_CUSTOMERS; i++) {
            customers[i].join();
        }

        // Verify that all seats are reserved
        for (int i = 0; i < NUM_THEATRES; i++) {
            for (int j = 0; j < SEATS_PER_THEATRE; j++) {
                if (!seats[i][j]) {
                    System.out.println("Seat " + j + " in theatre " + i + " is not reserved");
                }
            }
        }
    }
}
