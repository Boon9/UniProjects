import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.DoubleAdder;
import java.util.Map;
import java.util.stream.Collectors;
import org.apache.poi.ss.usermodel.*;

// The Dataset class encapsulates a 2D array of Strings representing the data.
class Dataset {
    private String[][] data;

    // Constructor for the Dataset class.
    public Dataset(String[][] data) {
        this.data = data;
    }

    // Method to return the encapsulated data.
    public String[][] getData() {
        return data;
    }
}

// The SummaryCalculator class is designed to be executed in a separate thread.
// It calculates the total money spent by each user and the total money spent by all users.
class SummaryCalculator implements Runnable {
    private Dataset dataset;
    private ConcurrentHashMap<String, DoubleAdder> userTotalSpending;
    private DoubleAdder totalMoneySpentByAllUsers;
    private int start;
    private int end;

    // Constructor for the SummaryCalculator class.
    public SummaryCalculator(Dataset dataset, int start, int end,
                             ConcurrentHashMap<String, DoubleAdder> userTotalSpending,
                             DoubleAdder totalMoneySpentByAllUsers) {
        this.dataset = dataset;
        this.start = start;
        this.end = end;
        this.userTotalSpending = userTotalSpending;
        this.totalMoneySpentByAllUsers = totalMoneySpentByAllUsers;
    }

    // Method run will be executed when the thread starts.
    @Override
    public void run() {
        // Process each row in the dataset from start to end.
        for (int i = start; i < end; i++) {
            // Skip the header row.
            if (i == 0 && start == 0) continue;
            try {
                String userId = dataset.getData()[i][2];
                double sharePrice = Double.parseDouble(dataset.getData()[i][0]);
                double shareBought = Double.parseDouble(dataset.getData()[i][4]);
                double total = sharePrice * shareBought;
                // Update user's total spending and the total spending of all users.
                userTotalSpending.computeIfAbsent(userId, k -> new DoubleAdder()).add(total);
                totalMoneySpentByAllUsers.add(total);
            } catch (NumberFormatException e) {
                // Handle number format exceptions.
                System.err.println("Error parsing number at row: " + i + ", data: " + Arrays.toString(dataset.getData()[i]));
                e.printStackTrace();
            }
        }
    }
}

// FinTechDataSummarised is the main class of the application.
// It coordinates the other classes to load the dataset from Excel, divide the dataset
// among multiple threads for processing, and then print out the summarized results.
class FinTechDataSummarised {
    // Use as many threads as there are available processors.
    private static final int NUM_THREADS = Runtime.getRuntime().availableProcessors();

    // This method reads data from an Excel file and returns it as a Dataset object.
    private static Dataset loadDatasetFromExcel(String filename) {
        Workbook workbook = null;
        try {
            FileInputStream file = new FileInputStream(filename);
            workbook = WorkbookFactory.create(file);
            Sheet sheet = workbook.getSheetAt(0);
            int numRows = sheet.getPhysicalNumberOfRows();
            int numCols = sheet.getRow(0).getLastCellNum();
            String[][] data = new String[numRows][numCols];
            int currentRow = 0;
            for (Row row : sheet) {
                if (row == null || row.getPhysicalNumberOfCells() == 0) continue;
                for (int j = 0; j < numCols; j++) {
                    Cell cell = row.getCell(j, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                    data[currentRow][j] = (cell == null) ? "" : cell.toString();
                }
                currentRow++;
            }
            return new Dataset(Arrays.copyOf(data, currentRow));
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (workbook != null) {
                try {
                    workbook.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    // This is the main method that gets executed when the program starts.
    public static void main(String[] args) throws InterruptedException {
        String filename = "18109082.xlsx";
        Dataset dataset = loadDatasetFromExcel(filename);
        if (dataset == null) {
            System.out.println("Failed to load the dataset from the Excel file.");
            return;
        }

        int NUM_TRANSACTIONS = dataset.getData().length;
        int transactionsPerThread = NUM_TRANSACTIONS / NUM_THREADS;
        ConcurrentHashMap<String, DoubleAdder> userTotalSpending = new ConcurrentHashMap<>();
        DoubleAdder totalMoneySpentByAllUsers = new DoubleAdder();
        Thread[] threads = new Thread[NUM_THREADS];

        // Split the work among the threads.
        for (int i = 0; i < NUM_THREADS; i++) {
            int start = i * transactionsPerThread;
            int end = (i == NUM_THREADS - 1) ? NUM_TRANSACTIONS : (i + 1) * transactionsPerThread;
            SummaryCalculator calculator = new SummaryCalculator(dataset, start, end, userTotalSpending, totalMoneySpentByAllUsers);
            threads[i] = new Thread(calculator);
            threads[i].start();
        }

        // Wait for all threads to finish.
        for (Thread thread : threads) {
            thread.join();
        }

        // Sort the userTotalSpending map by the user IDs (assumed to be integers) and print the results.
        Map<String, Double> sortedMap = userTotalSpending.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        e -> e.getValue().sum(),
                        (e1, e2) -> e1,
                        java.util.LinkedHashMap::new));

        System.out.println("user_id\ttotal_money_spent_by_each_user");
        sortedMap.forEach((userId, total) -> System.out.println(userId + "\t" + String.format("%.2f", total)));
        System.out.println("TOTAL\t" + String.format("%.2f", totalMoneySpentByAllUsers.sum()));
    }
}
